@echo off
setlocal
cd /d "%~dp0"
title HZRD BeatStep Cleaner - Ready to run
echo HZRD BeatStep Cleaner v2 is portable. No installation is needed.
echo Python, mido, python-rtmidi, pip and compiler tools are not used.
echo.
echo Keep loopMIDI open with a port named HZRD BeatStep.
echo Starting the cleaner...
call "%~dp0run.bat"
exit /b %errorlevel%
