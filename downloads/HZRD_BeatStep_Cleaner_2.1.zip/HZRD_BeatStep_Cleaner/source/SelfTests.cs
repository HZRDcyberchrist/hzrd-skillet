using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Hzrd.BeatStepCleaner
{
    internal static class SelfTests
    {
        private static int assertions;
        private static void Require(bool condition, string name)
        {
            assertions++;
            if (!condition) throw new InvalidOperationException("FAIL: " + name);
        }
        private static uint CC(int channel, int cc, int value) { return (uint)(0xB0 | channel) | ((uint)cc << 8) | ((uint)value << 16); }
        private static int Value(uint packed) { return (int)((packed >> 16) & 127); }
        private static void Sequence(RelativeFilter filter, int[] input, int[] expected, string name)
        {
            List<int> result = new List<int>(); uint cleaned;
            foreach (int v in input) if (filter.Process(CC(0, 7, v), out cleaned)) result.Add(Value(cleaned));
            Require(result.Count == expected.Length, name + " length");
            for (int i = 0; i < expected.Length; i++) Require(result[i] == expected[i], name + " pulse " + i);
        }
        internal static int Run(string report)
        {
            assertions = 0;
            StringBuilder text = new StringBuilder();
            try
            {
                uint cleaned;
                for (int v = 1; v < 128; v++)
                {
                    RelativeFilter fresh = new RelativeFilter(2, null);
                    bool sent = fresh.Process(CC(0, 7, v), out cleaned);
                    if (v == 64) Require(!sent, "neutral 64");
                    else { Require(sent, "first pulse always passes"); Require(Value(cleaned) == (v < 64 ? 1 : 127), "accelerated value " + v); }
                }
                RelativeFilter neutral = new RelativeFilter(2, null);
                Require(!neutral.Process(CC(0, 7, 0), out cleaned), "neutral zero");
                Sequence(new RelativeFilter(2, null), new int[] { 1, 1, 1, 127, 1, 1 }, new int[] { 1, 1, 1, 1, 1 }, "previous-chat glitch example");
                Sequence(new RelativeFilter(2, null), new int[] { 1, 1, 127, 127, 127, 127 }, new int[] { 1, 1, 127, 127, 127 }, "previous-chat reversal example");
                Sequence(new RelativeFilter(2, null), new int[] { 1, 127, 1, 127, 1, 127, 127 }, new int[] { 1, 1, 1, 127 }, "correct direction resets reversal count");
                Sequence(new RelativeFilter(3, null), new int[] { 2, 126, 125, 124, 2, 3, 4 }, new int[] { 1, 127, 1 }, "confirmation three");
                Sequence(new RelativeFilter(1, null), new int[] { 2, 126, 2, 126 }, new int[] { 1, 127, 1, 127 }, "instant reversals");
                Sequence(new RelativeFilter(4, null), new int[] { 2, 127, 127, 127, 127, 127 }, new int[] { 1, 127, 127 }, "confirmation four");
                Sequence(new RelativeFilter(2, null), new int[] { 1, 127, 0, 64, 127 }, new int[] { 1, 127 }, "neutral messages leave state untouched");

                RelativeFilter separate = new RelativeFilter(2, null);
                Require(separate.Process(CC(0, 7, 1), out cleaned), "knob one");
                Require(separate.Process(CC(0, 8, 127), out cleaned) && Value(cleaned) == 127, "knob two has independent initial direction");
                Require(separate.Process(CC(1, 7, 127), out cleaned) && Value(cleaned) == 127, "channel has independent direction");
                Require(!separate.Process(CC(0, 7, 127), out cleaned), "first reversal blocked");
                Require(separate.Process(CC(0, 8, 127), out cleaned), "other knob keeps moving");
                Require(separate.Process(CC(0, 7, 127), out cleaned), "second reversal confirms despite interleaved other knobs");
                bool[] mask = RelativeFilter.ParseControllers("7, 10, 20-35, 127");
                Require(mask[7] && mask[10] && mask[20] && mask[35] && mask[127] && !mask[19] && !mask[36], "controller range parsing");
                RelativeFilter selected = new RelativeFilter(2, mask);
                mask[7] = false;
                Require(selected.Process(CC(0, 7, 3), out cleaned) && Value(cleaned) == 1, "mask copied defensively");
                uint absolute = CC(0, 8, 64);
                Require(selected.Process(absolute, out cleaned) && cleaned == absolute, "unselected absolute CC unchanged");
                foreach (string invalid in new string[] { "", "-1", "128", "35-20", "7,,8", "foo", "7-8-9" })
                {
                    bool failed = false; try { RelativeFilter.ParseControllers(invalid); } catch (ArgumentException) { failed = true; }
                    Require(failed, "bad CC list rejected: " + invalid);
                }
                foreach (int invalid in new int[] { 0, 5 })
                {
                    bool failed = false; try { new RelativeFilter(invalid, null); } catch (ArgumentOutOfRangeException) { failed = true; }
                    Require(failed, "bad confirmation rejected");
                }
                RelativeFilter pass = new RelativeFilter(2, null);
                foreach (uint raw in new uint[] { 0x00643C90u, 0x00003C80u, 0x00403CA0u, 0x00000AC0u, 0x000040D0u, 0x004000E0u, 0x000000F8u, 0x000000FAu, 0x000000FCu, 0x000000FEu, 0x000202F2u })
                    Require(pass.Process(raw, out cleaned) && raw == cleaned, "non-CC MIDI unchanged " + raw.ToString("X"));

                // Independent simple reference model, including randomized cross-channel traffic.
                Random random = new Random(4487);
                for (int strength = 1; strength <= 4; strength++)
                {
                    int[,] directions = new int[16, 128], counts = new int[16, 128];
                    RelativeFilter actual = new RelativeFilter(strength, null);
                    for (int i = 0; i < 100000; i++)
                    {
                        int channel = random.Next(16), cc = random.Next(128), value = random.Next(128);
                        uint raw = CC(channel, cc, value);
                        bool shouldSend = value != 0 && value != 64;
                        int normalized = value < 64 ? 1 : 127;
                        if (shouldSend)
                        {
                            if (directions[channel, cc] == 0 || directions[channel, cc] == normalized)
                            { directions[channel, cc] = normalized; counts[channel, cc] = 0; }
                            else
                            {
                                counts[channel, cc]++;
                                if (counts[channel, cc] >= strength) { directions[channel, cc] = normalized; counts[channel, cc] = 0; }
                                else shouldSend = false;
                            }
                        }
                        bool wasSent = actual.Process(raw, out cleaned);
                        Require(wasSent == shouldSend, "randomized direction filtering");
                        if (wasSent) Require(Value(cleaned) == normalized && (cleaned & 0xFFFF) == (raw & 0xFFFF), "channel and controller preserved");
                    }
                }
                bool routeRejected = false;
                try { WinMidi.ValidateRoute(new MidiPort(0, "HZRD BeatStep"), new MidiPort(1, "hzrd beatstep")); }
                catch (ArgumentException) { routeRejected = true; }
                Require(routeRejected, "feedback route rejected");
                WinMidi.ValidateRoute(new MidiPort(0, "Arturia BeatStep"), new MidiPort(0, "HZRD BeatStep"));
                List<MidiPort> ports = new List<MidiPort>(); ports.Add(new MidiPort(0, "Microsoft GS Wavetable Synth"));
                Require(MidiPort.Preferred(ports, "missing", false) == null, "unrelated output not auto-selected");
                ports.Add(new MidiPort(1, "HZRD BeatStep"));
                Require(MidiPort.Preferred(ports, "missing", false).Id == 1, "expected loopMIDI auto-selected");
                bool staleRejected = false; try { MidiEngine.Find(ports, "HZRD BeatStep", 0); } catch (InvalidOperationException) { staleRejected = true; }
                Require(staleRejected, "reassigned port ID rejected");
                MidiEngine missing = new MidiEngine(new MidiPort(uint.MaxValue, "HZRD missing QA input"), new MidiPort(uint.MaxValue, "HZRD missing QA output"), 2, null);
                missing.Start();
                Require(missing.Join(3000), "missing-device worker finishes");
                Require(missing.State == "Error" && missing.Error != null && missing.Error.Contains("disconnected"), "missing-device startup gives a clear error");
                missing.RequestStop(); // A final stop request must remain safe after startup failure.
                Require(Marshal.SizeOf(typeof(WinMidi.InCaps)) == 76, "MIDIINCAPSW size");
                Require(Marshal.SizeOf(typeof(WinMidi.OutCaps)) == 84, "MIDIOUTCAPSW size");
                Require(WinMidi.HeaderSize == (IntPtr.Size == 8 ? 120 : 64), "MIDIHDR pointer size");
                Require(Marshal.OffsetOf(typeof(WinMidi.Header), "Recorded").ToInt32() == IntPtr.Size + 4, "dwBytesRecorded offset");
                MidiBuffer buffer = new MidiBuffer(128);
                Require(buffer.Read().Length == 128 && buffer.Read().Data == buffer.Data, "native buffer allocation");
                buffer.Free(); Require(buffer.Pointer == IntPtr.Zero, "native buffer release");

                string oldDirectory = Log.DirectoryPath;
                string testDirectory = Path.Combine(Path.GetDirectoryName(report), "settings-test-" + Guid.NewGuid().ToString("N"));
                Log.Configure(testDirectory);
                try
                {
                    Settings s = new Settings(); s.Input = "Arturia BeatStep & test"; s.Confirm = 3; s.AllControllers = false; s.Controllers = "7,20-35";
                    s.Save(); s.Confirm = 4; s.Save();
                    Settings loaded = Settings.Load();
                    Require(loaded.Input == s.Input && loaded.Confirm == 4 && !loaded.AllControllers && loaded.Controllers == s.Controllers, "atomic settings round-trip");
                    File.WriteAllText(Path.Combine(testDirectory, "settings.xml"), "broken XML");
                    loaded = Settings.Load(); Require(loaded.Confirm == 2 && loaded.Warning != null, "corrupt settings recover safely");
                }
                finally { Log.Configure(oldDirectory); }
                RelativeFilter speed = new RelativeFilter(2, null);
                Stopwatch stopwatch = Stopwatch.StartNew();
                for (int i = 0; i < 1000000; i++) speed.Process(CC(i & 15, (i >> 4) & 127, 1), out cleaned);
                stopwatch.Stop();
                text.AppendLine("PASS: " + assertions.ToString("N0") + " assertions.");
                text.AppendLine("Covered normalization, original Bome examples, confirmation 1-4, independent CC/channel state, neutral values, note/system passthrough, CC selection, feedback guard, stale port IDs, missing-device worker startup, WinMM structure sizes and settings recovery.");
                text.AppendLine("Filter-only throughput: 1,000,000 messages in " + stopwatch.ElapsedMilliseconds + " ms (not an end-to-end MIDI latency measurement).");
                text.AppendLine("Runtime: " + Environment.Version + "; process: " + (IntPtr.Size * 8) + "-bit.");
                File.WriteAllText(report, text.ToString()); return 0;
            }
            catch (Exception ex) { text.AppendLine(ex.ToString()); File.WriteAllText(report, text.ToString()); return 1; }
        }
        internal static int Diagnostics(string report)
        {
            try
            {
                StringBuilder text = new StringBuilder("HZRD BeatStep Cleaner v2.1 diagnostics\r\n");
                text.AppendLine("OS: " + Environment.OSVersion + "; Runtime: " + Environment.Version + "; " + (IntPtr.Size * 8) + "-bit process");
                text.AppendLine("INPUTS:"); foreach (MidiPort port in WinMidi.Inputs()) text.AppendLine("  " + port.Id + "  " + port.Name);
                text.AppendLine("OUTPUTS:"); foreach (MidiPort port in WinMidi.Outputs()) text.AppendLine("  " + port.Id + "  " + port.Name);
                text.AppendLine("PASS: Windows MIDI enumeration. No MIDI ports were opened and no messages were sent.");
                File.WriteAllText(report, text.ToString()); return 0;
            }
            catch (Exception ex) { File.WriteAllText(report, ex.ToString()); return 1; }
        }
        private static void CheckBounds(Control parent)
        {
            foreach (Control child in parent.Controls)
            {
                if (!child.Visible) continue;
                Require(child.Left >= 0 && child.Top >= 0 && child.Right <= parent.ClientSize.Width + 1 && child.Bottom <= parent.ClientSize.Height + 1,
                    "UI control inside parent: " + child.GetType().Name + " '" + child.Text + "'");
                if (child.HasChildren) CheckBounds(child);
            }
        }
        internal static int UiTest(string directory)
        {
            assertions = 0; Directory.CreateDirectory(directory);
            try
            {
                using (CleanerForm form = new CleanerForm())
                {
                    form.StopTimerForTest(); form.CreateControl(); form.RefreshForTest();
                    form.PreviewRunning(); form.CreateControl();
                    using (Bitmap bitmap = new Bitmap(form.Width, form.Height))
                    { form.DrawToBitmap(bitmap, form.ClientRectangle); bitmap.Save(Path.Combine(directory, "interface-preview.png")); }
                    // Preview form stays hidden: no physical MIDI is opened.
                    form.ShowInTaskbar = false; form.Opacity = 0;
                    form.Show(); Application.DoEvents(); form.StopTimerForTest(); form.PreviewRunning();
                    CheckBounds(form);
                    Require(form.Font.FontFamily.Name == "IBM Plex Mono", "embedded Altar typeface loaded");
                    Require(form.StartControl.Text == "STOP CLEANER", "running button label");
                    Require(form.StatusText == "[ LIVE ] Cleaner running", "running status label");
                    form.ClientSize = new Size(920, 780); Application.DoEvents(); CheckBounds(form);
                    form.ClientSize = new Size(720, 730); Application.DoEvents();
                    using (Bitmap bitmap = new Bitmap(form.Width, form.Height))
                    { form.DrawToBitmap(bitmap, new Rectangle(0, 0, form.Width, form.Height)); bitmap.Save(Path.Combine(directory, "interface-preview.png")); }
                    form.RefreshForTest();
                    form.InputControl.Items.Clear(); form.OutputControl.Items.Clear();
                    form.InputControl.Items.Add(new MidiPort(0, "HZRD BeatStep")); form.OutputControl.Items.Add(new MidiPort(0, "HZRD BeatStep"));
                    form.InputControl.SelectedIndex = form.OutputControl.SelectedIndex = 0;
                    Require(!form.StartControl.Enabled, "GUI disables feedback route");
                    Require(form.StatusText == "Choose two different ports", "GUI explains feedback prevention");
                    form.InputControl.SelectedIndex = -1;
                    form.InputControl.Items.Clear();
                    Require(!form.StartControl.Enabled, "GUI disables missing input");
                    Require(form.StatusText == "Let's connect your BeatStep", "GUI explains missing input");
                    form.Close();
                }
                File.WriteAllText(Path.Combine(directory, "ui-test.txt"), "PASS: " + assertions + " UI assertions; bounds, resizing, simulated running view, feedback protection, missing input. No MIDI ports opened.\r\n");
                return 0;
            }
            catch (Exception ex) { File.WriteAllText(Path.Combine(directory, "ui-test.txt"), ex.ToString()); return 1; }
        }
    }
}
