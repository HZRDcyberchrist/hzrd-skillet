using System;
using System.Collections.Generic;

namespace Hzrd.BeatStepCleaner
{
    // One direction and reversal count for each (channel, controller).
    // Same-direction pulses always pass. Only consecutive opposing pulses
    // count toward a reversal; no buffered pulses are replayed.
    internal sealed class RelativeFilter
    {
        private readonly int[,] direction = new int[16, 128];
        private readonly int[,] reversal = new int[16, 128];
        private readonly bool[] controllers;
        internal readonly int Confirmation;

        internal RelativeFilter(int confirmation, bool[] selectedControllers)
        {
            if (confirmation < 1 || confirmation > 4) throw new ArgumentOutOfRangeException("confirmation");
            if (selectedControllers != null && selectedControllers.Length != 128)
                throw new ArgumentException("A controller mask must contain 128 entries.");
            Confirmation = confirmation;
            controllers = selectedControllers == null ? null : (bool[])selectedControllers.Clone();
        }

        internal bool Process(uint raw, out uint cleaned)
        {
            cleaned = raw;
            int status = (int)(raw & 255);
            if ((status & 240) != 176) return true;
            int channel = status & 15;
            int cc = (int)((raw >> 8) & 127);
            if (controllers != null && !controllers[cc]) return true;
            int value = (int)((raw >> 16) & 127);
            // 0 and 64 are neutral, not movement. They do not change state.
            if (value == 0 || value == 64) return false;
            int next = value < 64 ? 1 : 127;
            if (direction[channel, cc] == 0) direction[channel, cc] = next;
            if (next == direction[channel, cc]) reversal[channel, cc] = 0;
            else
            {
                reversal[channel, cc]++;
                if (reversal[channel, cc] < Confirmation) return false;
                direction[channel, cc] = next;
                reversal[channel, cc] = 0;
            }
            cleaned = (raw & 0xFF00FFFFu) | ((uint)next << 16);
            return true;
        }

        internal static bool[] ParseControllers(string text)
        {
            bool[] mask = new bool[128];
            bool any = false;
            foreach (string entry in (text ?? "").Split(','))
            {
                string token = entry.Trim();
                string[] range = token.Split('-');
                int first, last;
                if (range.Length > 2 || !int.TryParse(range[0].Trim(), out first))
                    throw new ArgumentException("Enter CC numbers like 7, 10, 20-35 (from 0 to 127).");
                last = first;
                if (range.Length == 2 && !int.TryParse(range[1].Trim(), out last))
                    throw new ArgumentException("Enter ranges like 20-35.");
                if (first < 0 || last > 127 || last < first)
                    throw new ArgumentException("CC numbers must be 0-127, and ranges must run upward.");
                for (int cc = first; cc <= last; cc++) mask[cc] = true;
                any = true;
            }
            if (!any) throw new ArgumentException("Enter at least one encoder CC.");
            return mask;
        }
    }

    internal sealed class MidiPort
    {
        internal readonly uint Id;
        internal readonly string Name;
        internal MidiPort(uint id, string name) { Id = id; Name = name; }
        public override string ToString() { return Name; }

        internal static MidiPort Preferred(List<MidiPort> ports, string saved, bool input)
        {
            foreach (MidiPort p in ports) if (p.Name == saved) return p;
            string target = input ? "Arturia BeatStep" : "HZRD BeatStep";
            foreach (MidiPort p in ports) if (string.Equals(p.Name, target, StringComparison.OrdinalIgnoreCase)) return p;
            foreach (MidiPort p in ports)
                if (p.Name.IndexOf(target, StringComparison.OrdinalIgnoreCase) >= 0) return p;
            // Never select a synthesizer or unrelated controller automatically.
            return null;
        }
    }
}
