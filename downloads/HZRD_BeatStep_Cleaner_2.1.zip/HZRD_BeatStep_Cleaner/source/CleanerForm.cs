using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Hzrd.BeatStepCleaner
{
    internal sealed class CleanerForm : Form
    {
        private Settings settings;
        private MidiEngine engine;
        private readonly ComboBox inputs = new DarkCombo(), outputs = new DarkCombo(), confirm = new DarkCombo();
        private readonly CheckBox all = new DarkCheckBox();
        private readonly TextBox controllers = new TextBox();
        private readonly SoftButton start = new SoftButton(), refresh = new SoftButton();
        private readonly Label status = new Label(), detail = new Label(), latest = new Label();
        private readonly Label received = new Label();
        private readonly KnobBuddy buddy = new KnobBuddy();
        private readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        private readonly ToolTip tips = new ToolTip();
        private bool stopping, reportedError, closing;
        private int ambientTick;
        [DllImport("dwmapi.dll")] private static extern int DwmSetWindowAttribute(IntPtr window, int attribute, ref int value, int size);

        internal CleanerForm()
        {
            settings = Settings.Load();
            Text = "HZRD BeatStep Cleaner // Altar";
            BackColor = Theme.Background; ForeColor = Theme.Text;
            Font = new Font(Theme.Family, 10);
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96, 96);
            ClientSize = new Size(720, 730); MinimumSize = new Size(710, 765);
            StartPosition = FormStartPosition.CenterScreen;
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
            BuildInterface();
            Load += delegate { RefreshPorts(); if (settings.Warning != null) SetStatus("Check settings", settings.Warning, Theme.Warning); };
            timer.Interval = 100; timer.Tick += delegate
            {
                UpdateEngine();
                // Only the small decorative header updates at 1 Hz. MIDI has its own worker.
                if (++ambientTick % 10 == 0 && WindowState != FormWindowState.Minimized)
                    Invalidate(new Rectangle(430, 30, Math.Max(0, ClientSize.Width - 450), 78));
            }; timer.Start();
            FormClosing += OnClosing;
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try
            {
                int dark = 1; DwmSetWindowAttribute(Handle, 20, ref dark, 4);
                int caption = Theme.Background.R | (Theme.Background.G << 8) | (Theme.Background.B << 16);
                int ink = Theme.Green.R | (Theme.Green.G << 8) | (Theme.Green.B << 16);
                DwmSetWindowAttribute(Handle, 35, ref caption, 4); DwmSetWindowAttribute(Handle, 36, ref ink, 4);
            }
            catch (DllNotFoundException) { }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            // Quiet, deterministic ASCII drift echoes Altar without obscuring controls.
            using (Font font = new Font(Theme.Family, 7))
            using (Brush ghost = new SolidBrush(Theme.Dim))
            {
                const string glyphs = "hzrd./altar{}[]<>+;:@=|";
                int phase = ambientTick / 10;
                for (int row = 0; row < 6; row++)
                    for (int col = 0; col < Math.Max(0, (ClientSize.Width - 445) / 9); col++)
                    {
                        int seed = col * 37 + (row + phase) * 13;
                        if (seed % 5 < 2) continue;
                        e.Graphics.DrawString(glyphs[seed % glyphs.Length].ToString(), font, ghost, 430 + col * 9, 35 + row * 12);
                    }
            }
            using (Brush strip = new SolidBrush(Theme.Green)) e.Graphics.FillRectangle(strip, 0, ClientSize.Height - 20, ClientSize.Width, 20);
            using (Font font = new Font(Theme.Family, 8))
            {
                TextRenderer.DrawText(e.Graphics, "HZRD//OS  /  BEATSTEP v2.1", font, new Rectangle(12, ClientSize.Height - 20, ClientSize.Width - 24, 20),
                    Theme.Background, TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
                TextRenderer.DrawText(e.Graphics, "AVE MACHINA", font, new Rectangle(12, ClientSize.Height - 20, ClientSize.Width - 24, 20),
                    Theme.Background, TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
            }
        }

        private Label LabelAt(string text, int x, int y, int width, int height, float size, Color color, Control parent)
        {
            Label label = new Label(); label.Text = text; label.SetBounds(x, y, width, height);
            label.ForeColor = color; label.BackColor = Color.Transparent; label.Font = new Font(Theme.Family, size);
            parent.Controls.Add(label); return label;
        }
        private CardPanel Card(int y, int height)
        {
            CardPanel card = new CardPanel(); card.SetBounds(22, y, ClientSize.Width - 44, height);
            card.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            Controls.Add(card); return card;
        }
        private void StyleCombo(ComboBox combo, Control parent, int x, int y, int width)
        {
            combo.SetBounds(x, y, width, 30); combo.DropDownStyle = ComboBoxStyle.DropDownList;
            combo.BackColor = Theme.Input; combo.ForeColor = Theme.Text; combo.FlatStyle = FlatStyle.Flat;
            combo.IntegralHeight = false; combo.DropDownHeight = 180;
            parent.Controls.Add(combo);
        }
        private void BuildInterface()
        {
            buddy.SetBounds(22, 17, 80, 80); Controls.Add(buddy);
            LabelAt("hzrd@archive:~$ ./beatstep_cleaner_", 112, 19, 580, 24, 9, Theme.Green, this).Font = new Font(Theme.Family, 10, FontStyle.Bold);
            LabelAt("BeatStep Cleaner", 108, 41, 425, 38, 23, Theme.Text, this).Font = new Font(Theme.Family, 23, FontStyle.Bold);
            LabelAt("RELATIVE #2  /  SIXTEEN ENCODERS", 112, 82, 530, 24, 10, Theme.Muted, this);
            Label version = LabelAt("v2.1 / altar", ClientSize.Width - 150, 20, 130, 20, 9, Theme.Muted, this);
            version.Anchor = AnchorStyles.Top | AnchorStyles.Right; version.TextAlign = ContentAlignment.TopRight;

            CardPanel ports = Card(118, 177);
            LabelAt("01 / CONNECT YOUR MIDI", 18, 13, 400, 23, 9, Theme.Green, ports).Font = new Font(Theme.Family, 9, FontStyle.Bold);
            refresh.Font = new Font(Theme.Family, 9); refresh.Text = "Refresh ports"; refresh.ForeColor = Theme.Text;
            refresh.SetBounds(ports.Width - 158, 9, 140, 31); refresh.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            ports.Controls.Add(refresh); refresh.Click += delegate { RefreshPorts(); };
            LabelAt("INPUT  /  your controller", 18, 50, 500, 22, 9, Theme.Muted, ports);
            StyleCombo(inputs, ports, 18, 74, ports.Width - 36); inputs.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            LabelAt("OUTPUT  /  your loopMIDI port", 18, 110, 500, 22, 9, Theme.Muted, ports);
            StyleCombo(outputs, ports, 18, 134, ports.Width - 36); outputs.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            inputs.SelectedIndexChanged += delegate { UpdateReady(); };
            outputs.SelectedIndexChanged += delegate { UpdateReady(); };

            CardPanel tuning = Card(307, 172);
            LabelAt("02 / MAKE IT FEEL RIGHT", 18, 13, 600, 23, 9, Theme.Green, tuning).Font = new Font(Theme.Family, 9, FontStyle.Bold);
            LabelAt("Direction Confirm", 18, 51, 150, 28, 10, Theme.Text, tuning);
            StyleCombo(confirm, tuning, 170, 47, tuning.Width - 188); confirm.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            confirm.Items.AddRange(new object[] { "1   /   instant reversals", "2   /   balanced (recommended)", "3   /   stronger filtering", "4   /   maximum filtering" });
            confirm.SelectedIndex = settings.Confirm - 1;
            LabelAt("More confirmation = fewer twitches, slower direction changes.", 18, 83, 630, 22, 9, Theme.Muted, tuning);
            all.Text = "Clean all CCs"; all.Checked = settings.AllControllers; all.ForeColor = Theme.Text;
            all.BackColor = Theme.Card; all.SetBounds(18, 115, 145, 25); tuning.Controls.Add(all);
            controllers.SetBounds(170, 114, tuning.Width - 188, 29); controllers.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            controllers.Text = settings.Controllers; controllers.BackColor = Theme.Input; controllers.ForeColor = Theme.Text;
            controllers.BorderStyle = BorderStyle.FixedSingle; controllers.Enabled = !all.Checked; tuning.Controls.Add(controllers);
            LabelAt("Uncheck to select encoder CCs: 7, 10, 20-35. Others pass through.", 18, 143, 630, 22, 9, Theme.Muted, tuning);
            all.CheckedChanged += delegate { controllers.Enabled = !all.Checked && engine == null; };
            tips.SetToolTip(all, "All CCs are assumed to be relative encoders. If a button sends an absolute CC, select only your encoder CCs.");
            tips.SetToolTip(confirm, "Correct-direction pulses pass immediately. A direction change needs this many consecutive opposing pulses.");
            tips.SetToolTip(controllers, "Numbers 0-127, separated by commas. Ranges such as 20-35 are supported.");

            CardPanel activity = Card(491, 104);
            status.SetBounds(18, 12, activity.Width - 36, 26); status.Font = new Font(Theme.Family, 12, FontStyle.Bold);
            status.BackColor = Color.Transparent; status.ForeColor = Theme.Green; activity.Controls.Add(status);
            status.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            detail.SetBounds(18, 43, activity.Width - 36, 45); detail.BackColor = Color.Transparent;
            detail.Font = new Font(Theme.Family, 9); detail.ForeColor = Theme.Muted;
            detail.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; activity.Controls.Add(detail);

            start.Text = "START CLEANER"; start.Fill = Theme.Green; start.ForeColor = Theme.Background;
            start.Font = new Font(Theme.Family, 12, FontStyle.Bold);
            start.SetBounds(22, 609, ClientSize.Width - 44, 51); start.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            Controls.Add(start); start.Click += delegate { ToggleCleaner(); };
            Label activityLine = LabelAt("IN  0       OUT  0       FILTERED  0", 22, 671, 440, 20, 9, Theme.Muted, this);
            // Use one line for counters to keep the window compact on stage.
            received.Tag = activityLine;
            latest.SetBounds(22, 690, ClientSize.Width - 44, 18); latest.BackColor = Color.Transparent;
            latest.Font = new Font(Theme.Family, 8); latest.ForeColor = Theme.Green; latest.Text = "Waiting for your first knob turn...";
            latest.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; Controls.Add(latest);
            LinkLabel help = new LinkLabel(); help.Text = "Setup & help";
            help.LinkColor = Theme.Green; help.ActiveLinkColor = Theme.Warning; help.VisitedLinkColor = Theme.Green;
            help.SetBounds(ClientSize.Width - 130, 671, 108, 24); help.TextAlign = ContentAlignment.TopRight;
            help.Anchor = AnchorStyles.Top | AnchorStyles.Right; Controls.Add(help); help.LinkClicked += delegate { ShowHelp(); };
            AcceptButton = start;
        }

        private void SetStatus(string title, string message, Color color)
        {
            status.Text = title; status.ForeColor = color; detail.Text = message;
        }
        private void RefreshPorts()
        {
            if (engine != null) return;
            string previousInput = inputs.SelectedItem == null ? settings.Input : ((MidiPort)inputs.SelectedItem).Name;
            string previousOutput = outputs.SelectedItem == null ? settings.Output : ((MidiPort)outputs.SelectedItem).Name;
            try
            {
                List<MidiPort> inputList = WinMidi.Inputs(), outputList = WinMidi.Outputs();
                inputs.Items.Clear(); outputs.Items.Clear();
                inputs.Items.AddRange(inputList.ToArray()); outputs.Items.AddRange(outputList.ToArray());
                inputs.SelectedItem = MidiPort.Preferred(inputList, previousInput, true);
                outputs.SelectedItem = MidiPort.Preferred(outputList, previousOutput, false);
                UpdateReady();
            }
            catch (Exception ex) { SetStatus("Couldn't read MIDI ports", ex.Message, Theme.Warning); Log.Write(ex.ToString()); }
        }
        private void UpdateReady()
        {
            if (engine != null) return;
            MidiPort from = inputs.SelectedItem as MidiPort, to = outputs.SelectedItem as MidiPort;
            start.Enabled = from != null && to != null;
            if (from == null) SetStatus("Let's connect your BeatStep", "Plug in the BeatStep, close apps using its MIDI input, then refresh and choose the input.", Theme.Green);
            else if (to == null) SetStatus("Your output is missing", "Open loopMIDI and create a port named HZRD BeatStep, then refresh and choose the output.", Theme.Green);
            else if (string.Equals(from.Name, to.Name, StringComparison.OrdinalIgnoreCase))
            {
                start.Enabled = false; SetStatus("Choose two different ports", "Use Arturia BeatStep as INPUT and HZRD BeatStep as OUTPUT to prevent a MIDI loop.", Theme.Warning);
            }
            else SetStatus("Ready when you are", "BeatStep: Relative #2, acceleration Slow. In Resolume, enable HZRD BeatStep and map your knobs as Relative.", Theme.Green);
        }
        private void ToggleCleaner()
        {
            if (engine != null)
            {
                stopping = true; start.Enabled = false; start.Text = "STOPPING...";
                SetStatus("Finishing up", "Releasing MIDI ports...", Theme.Green); engine.RequestStop(); return;
            }
            try
            {
                bool[] mask = all.Checked ? null : RelativeFilter.ParseControllers(controllers.Text);
                MidiPort from = inputs.SelectedItem as MidiPort, to = outputs.SelectedItem as MidiPort;
                WinMidi.ValidateRoute(from, to);
                settings.Input = from.Name; settings.Output = to.Name; settings.Confirm = confirm.SelectedIndex + 1;
                settings.AllControllers = all.Checked; settings.Controllers = controllers.Text;
                try { settings.Save(); }
                catch (Exception ex) { Log.Write("Could not save settings: " + ex.Message); MessageBox.Show(this, "The cleaner can run, but your settings could not be saved.\n\n" + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Information); }
                engine = new MidiEngine(from, to, settings.Confirm, mask);
                stopping = reportedError = false;
                SetConfigurationEnabled(false); start.Text = "CONNECTING..."; start.Enabled = false;
                SetStatus("Connecting", "Opening your MIDI ports...", Theme.Green); engine.Start();
            }
            catch (Exception ex) { SetStatus("Check your setup", ex.Message, Theme.Warning); Log.Write(ex.ToString()); }
        }
        private void SetConfigurationEnabled(bool enabled)
        {
            inputs.Enabled = outputs.Enabled = refresh.Enabled = confirm.Enabled = all.Enabled = enabled;
            controllers.Enabled = enabled && !all.Checked;
        }
        private void UpdateEngine()
        {
            if (engine == null) return;
            Label counters = (Label)received.Tag;
            counters.Text = "IN  " + Interlocked.Read(ref engine.Received).ToString("N0") + "       OUT  " + Interlocked.Read(ref engine.Sent).ToString("N0") +
                "       FILTERED  " + Interlocked.Read(ref engine.Filtered).ToString("N0");
            latest.Text = engine.Latest;
            if (engine.State == "Running" && !stopping)
            {
                start.Text = "STOP CLEANER"; start.Fill = Theme.Green; start.Enabled = true;
                buddy.Active = true; buddy.Invalidate();
                SetStatus("[ LIVE ] Cleaner running", "Turn a knob to see raw -> cleaned values below. Notes, pads and other MIDI pass through unchanged.", Theme.Green);
            }
            if (engine.State == "Stopped" || engine.State == "Error")
            {
                string error = engine.Error;
                engine.Join(100); engine.DisposeSignal(); engine = null; stopping = false;
                SetConfigurationEnabled(true); start.Text = "START CLEANER"; start.Fill = Theme.Green;
                buddy.Active = false; buddy.Invalidate(); UpdateReady();
                if (error != null)
                {
                    SetStatus("Routing stopped", error, Theme.Warning);
                    if (!reportedError && !closing)
                    {
                        reportedError = true;
                        MessageBox.Show(this, error + "\n\nUse Refresh ports after fixing the connection.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else SetStatus("Cleaner stopped", "Your MIDI ports are released. Press Start whenever you're ready.", Theme.Green);
            }
        }
        private void ShowHelp()
        {
            using (Form help = new Form())
            {
                help.Text = "Your quick setup guide"; help.BackColor = Theme.Background; help.ForeColor = Theme.Text;
                help.Font = Font; help.ClientSize = new Size(600, 520); help.StartPosition = FormStartPosition.CenterParent;
                help.FormBorderStyle = FormBorderStyle.FixedDialog; help.MaximizeBox = help.MinimizeBox = false;
                LabelAt("Small setup. Smoother moves.", 24, 20, 545, 36, 19, Theme.Green, help);
                LabelAt("1. Connect the Arturia BeatStep. In MIDI Control Center, set\n    the encoders to Relative #2 and acceleration to Slow.\n\n" +
                    "2. Open loopMIDI. Create or keep a port named HZRD BeatStep.\n\n" +
                    "3. Select Arturia BeatStep as INPUT and HZRD BeatStep as\n    OUTPUT, then press START CLEANER.\n\n" +
                    "4. In Resolume: Arturia BeatStep input OFF, HZRD BeatStep\n    input ON. Map encoders as Relative. Close the old cleaner\n    and Bome so they don't compete for the input.\n\n" +
                    "Direction Confirm 2 matches your previous filtering.\nTry 1 for quicker reversals or 3 for fewer wrong-way twitches.\n\n" +
                    "Clean all CCs assumes every CC is a relative encoder.\nIf buttons use absolute CCs, select only the encoder CCs.\nNeutral values 0 / 64 are ignored for selected encoders.\n\n" +
                    "Keep loopMIDI and this cleaner open during your session.", 24, 70, 550, 372, 10, Theme.Text, help);
                SoftButton logs = new SoftButton(); logs.Text = "Open settings & logs"; logs.ForeColor = Theme.Text; logs.SetBounds(24, 462, 240, 38);
                help.Controls.Add(logs); logs.Click += delegate
                {
                    try { Directory.CreateDirectory(Log.DirectoryPath); Process.Start(new ProcessStartInfo("explorer.exe", "\"" + Log.DirectoryPath + "\"") { UseShellExecute = true }); }
                    catch (Exception ex) { MessageBox.Show(help, ex.Message, "Couldn't open folder"); }
                };
                SoftButton done = new SoftButton(); done.Text = "Got it"; done.Fill = Theme.Green; done.ForeColor = Theme.Background;
                done.SetBounds(410, 462, 164, 38); done.DialogResult = DialogResult.OK; help.Controls.Add(done);
                help.AcceptButton = done; help.CancelButton = done; help.ShowDialog(this);
            }
        }
        private void OnClosing(object sender, FormClosingEventArgs e)
        {
            closing = true;
            if (engine != null)
            {
                engine.RequestStop();
                if (!engine.Join(3000))
                {
                    e.Cancel = true; closing = false; stopping = true;
                    start.Text = "STOPPING..."; start.Enabled = false;
                    SetStatus("Waiting for the MIDI driver", "The driver is taking time to release the ports. Reconnect the device if it remains stuck.", Theme.Warning);
                    return;
                }
                engine.DisposeSignal();
            }
            try
            {
                if (inputs.SelectedItem != null) settings.Input = ((MidiPort)inputs.SelectedItem).Name;
                if (outputs.SelectedItem != null) settings.Output = ((MidiPort)outputs.SelectedItem).Name;
                settings.Confirm = confirm.SelectedIndex + 1; settings.AllControllers = all.Checked; settings.Controllers = controllers.Text;
                settings.Save();
            }
            catch (Exception ex) { Log.Write("Could not save settings: " + ex.Message); }
            timer.Stop(); timer.Dispose(); tips.Dispose();
        }

        internal void PreviewRunning()
        {
            inputs.Items.Clear(); outputs.Items.Clear();
            inputs.Items.Add(new MidiPort(0, "Arturia BeatStep")); outputs.Items.Add(new MidiPort(0, "HZRD BeatStep"));
            inputs.SelectedIndex = outputs.SelectedIndex = 0;
            SetStatus("[ LIVE ] Cleaner running", "Turn a knob to see raw -> cleaned values below. Notes, pads and other MIDI pass through unchanged.", Theme.Green);
            buddy.Active = true; buddy.Invalidate(); start.Text = "STOP CLEANER"; start.Fill = Theme.Green;
            ((Label)received.Tag).Text = "IN  1,024       OUT  996       FILTERED  28";
            latest.Text = "CH 1   CC 7   3  ->  1";
            SetConfigurationEnabled(false);
        }
        internal void StopTimerForTest() { timer.Stop(); }
        internal ComboBox InputControl { get { return inputs; } }
        internal ComboBox OutputControl { get { return outputs; } }
        internal SoftButton StartControl { get { return start; } }
        internal string StatusText { get { return status.Text; } }
        internal void RefreshForTest() { RefreshPorts(); }
    }
}
