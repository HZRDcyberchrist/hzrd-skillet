using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace Hzrd.BeatStepCleaner
{
    internal static class WinMidi
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        internal struct InCaps
        {
            internal ushort Mid, Pid;
            internal uint Version;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] internal string Name;
            internal uint Support;
        }
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        internal struct OutCaps
        {
            internal ushort Mid, Pid;
            internal uint Version;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] internal string Name;
            internal ushort Technology, Voices, Notes, ChannelMask;
            internal uint Support;
        }
        [StructLayout(LayoutKind.Sequential)]
        internal struct Header
        {
            internal IntPtr Data;
            internal uint Length, Recorded;
            internal UIntPtr User;
            internal uint Flags;
            internal IntPtr Next;
            internal UIntPtr Reserved;
            internal uint Offset;
            internal UIntPtr R0, R1, R2, R3, R4, R5, R6, R7;
        }
        [UnmanagedFunctionPointer(CallingConvention.Winapi)]
        internal delegate void InCallback(IntPtr device, uint message, UIntPtr instance, UIntPtr data, UIntPtr time);
        internal static readonly uint HeaderSize = (uint)Marshal.SizeOf(typeof(Header));

        [DllImport("winmm.dll")] internal static extern uint midiInGetNumDevs();
        [DllImport("winmm.dll")] internal static extern uint midiOutGetNumDevs();
        [DllImport("winmm.dll", CharSet = CharSet.Unicode)] internal static extern uint midiInGetDevCapsW(UIntPtr id, out InCaps caps, uint size);
        [DllImport("winmm.dll", CharSet = CharSet.Unicode)] internal static extern uint midiOutGetDevCapsW(UIntPtr id, out OutCaps caps, uint size);
        [DllImport("winmm.dll")] internal static extern uint midiInOpen(out IntPtr device, uint id, InCallback callback, UIntPtr instance, uint flags);
        [DllImport("winmm.dll")] internal static extern uint midiOutOpen(out IntPtr device, uint id, IntPtr callback, UIntPtr instance, uint flags);
        [DllImport("winmm.dll")] internal static extern uint midiInStart(IntPtr device);
        [DllImport("winmm.dll")] internal static extern uint midiInStop(IntPtr device);
        [DllImport("winmm.dll")] internal static extern uint midiInReset(IntPtr device);
        [DllImport("winmm.dll")] internal static extern uint midiInClose(IntPtr device);
        [DllImport("winmm.dll")] internal static extern uint midiOutReset(IntPtr device);
        [DllImport("winmm.dll")] internal static extern uint midiOutClose(IntPtr device);
        [DllImport("winmm.dll")] internal static extern uint midiOutShortMsg(IntPtr device, uint data);
        [DllImport("winmm.dll")] internal static extern uint midiInPrepareHeader(IntPtr device, IntPtr header, uint size);
        [DllImport("winmm.dll")] internal static extern uint midiInUnprepareHeader(IntPtr device, IntPtr header, uint size);
        [DllImport("winmm.dll")] internal static extern uint midiInAddBuffer(IntPtr device, IntPtr header, uint size);
        [DllImport("winmm.dll")] internal static extern uint midiOutPrepareHeader(IntPtr device, IntPtr header, uint size);
        [DllImport("winmm.dll")] internal static extern uint midiOutUnprepareHeader(IntPtr device, IntPtr header, uint size);
        [DllImport("winmm.dll")] internal static extern uint midiOutLongMsg(IntPtr device, IntPtr header, uint size);
        [DllImport("winmm.dll", CharSet = CharSet.Unicode)] private static extern uint midiInGetErrorTextW(uint code, StringBuilder text, uint size);
        [DllImport("winmm.dll", CharSet = CharSet.Unicode)] private static extern uint midiOutGetErrorTextW(uint code, StringBuilder text, uint size);

        internal static void Check(uint result, string action, bool input)
        {
            if (result == 0) return;
            StringBuilder text = new StringBuilder(256);
            if (input) midiInGetErrorTextW(result, text, 256); else midiOutGetErrorTextW(result, text, 256);
            string hint = result == 4 ? " Close Bome, MIDI Control Center, or any app using this port, then try again." :
                " Check the USB connection and loopMIDI, then refresh the ports.";
            throw new InvalidOperationException(action + ": " + text + " (code " + result + ")." + hint);
        }
        internal static List<MidiPort> Inputs()
        {
            List<MidiPort> ports = new List<MidiPort>();
            for (uint id = 0; id < midiInGetNumDevs(); id++)
            {
                InCaps caps;
                Check(midiInGetDevCapsW(new UIntPtr(id), out caps, (uint)Marshal.SizeOf(typeof(InCaps))), "Read input port", true);
                ports.Add(new MidiPort(id, caps.Name));
            }
            return ports;
        }
        internal static List<MidiPort> Outputs()
        {
            List<MidiPort> ports = new List<MidiPort>();
            for (uint id = 0; id < midiOutGetNumDevs(); id++)
            {
                OutCaps caps;
                Check(midiOutGetDevCapsW(new UIntPtr(id), out caps, (uint)Marshal.SizeOf(typeof(OutCaps))), "Read output port", false);
                ports.Add(new MidiPort(id, caps.Name));
            }
            return ports;
        }
        internal static void ValidateRoute(MidiPort input, MidiPort output)
        {
            if (input == null || output == null) throw new ArgumentException("Choose both a MIDI input and output first.");
            if (string.Equals(input.Name, output.Name, StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("Input and output must be different ports. Choose Arturia BeatStep as input and HZRD BeatStep as output.");
        }
    }

    internal sealed class MidiBuffer
    {
        internal IntPtr Pointer, Data;
        internal bool Prepared;
        internal MidiBuffer(int capacity)
        {
            Data = Marshal.AllocHGlobal(capacity);
            try
            {
                Pointer = Marshal.AllocHGlobal((int)WinMidi.HeaderSize);
                WinMidi.Header header = new WinMidi.Header();
                header.Data = Data;
                header.Length = (uint)capacity;
                Marshal.StructureToPtr(header, Pointer, false);
            }
            catch { Marshal.FreeHGlobal(Data); throw; }
        }
        internal WinMidi.Header Read() { return (WinMidi.Header)Marshal.PtrToStructure(Pointer, typeof(WinMidi.Header)); }
        internal void Free()
        {
            if (Pointer != IntPtr.Zero) Marshal.FreeHGlobal(Pointer);
            if (Data != IntPtr.Zero) Marshal.FreeHGlobal(Data);
            Pointer = Data = IntPtr.Zero;
        }
    }

    internal sealed class MidiEngine
    {
        private struct Packet { internal uint Kind; internal UIntPtr Data; }
        private readonly ConcurrentQueue<Packet> queue = new ConcurrentQueue<Packet>();
        private readonly AutoResetEvent signal = new AutoResetEvent(false);
        private readonly List<MidiBuffer> inputBuffers = new List<MidiBuffer>();
        private readonly List<MidiBuffer> outputBuffers = new List<MidiBuffer>();
        private readonly MemoryStream sysex = new MemoryStream();
        private readonly RelativeFilter filter;
        private readonly MidiPort inputPort, outputPort;
        private readonly WinMidi.InCallback callback;
        private Thread worker;
        private IntPtr input, output;
        private int queued;
        private volatile bool stop;
        private volatile string callbackError;
        internal volatile string State = "Starting";
        internal volatile string Error;
        internal volatile string Latest = "Waiting for your first knob turn...";
        internal long Received, Sent, Filtered;

        internal MidiEngine(MidiPort from, MidiPort to, int confirm, bool[] mask)
        {
            WinMidi.ValidateRoute(from, to);
            inputPort = from; outputPort = to;
            filter = new RelativeFilter(confirm, mask);
            callback = OnInput;
        }
        internal void Start()
        {
            worker = new Thread(Run); worker.IsBackground = true;
            worker.Name = "HZRD MIDI routing";
            worker.Start();
        }
        internal void RequestStop() { stop = true; signal.Set(); }
        internal bool Join(int milliseconds) { return worker == null || worker.Join(milliseconds); }
        internal void DisposeSignal() { if (Error == null && (worker == null || !worker.IsAlive)) signal.Dispose(); }

        private void OnInput(IntPtr device, uint message, UIntPtr instance, UIntPtr data, UIntPtr timestamp)
        {
            // Never call WinMM or touch controls here: the driver owns this callback.
            if (stop) return;
            if (message != 0x3C3 && message != 0x3CC && message != 0x3C4 && message != 0x3C5 && message != 0x3C6) return;
            try
            {
                if (Interlocked.Increment(ref queued) > 8192)
                {
                    Interlocked.Decrement(ref queued);
                    callbackError = "MIDI input overflow. Routing stopped to prevent delayed or lost notes. Check for a MIDI feedback loop.";
                }
                else { Packet packet = new Packet(); packet.Kind = message; packet.Data = data; queue.Enqueue(packet); }
                signal.Set();
            }
            catch { callbackError = "The MIDI input driver reported an unexpected error. Stop and reconnect your device."; }
        }

        private void Run()
        {
            try
            {
                // Refresh IDs immediately before opening: unplugging changes port numbering.
                MidiPort from = Find(WinMidi.Inputs(), inputPort.Name, inputPort.Id);
                MidiPort to = Find(WinMidi.Outputs(), outputPort.Name, outputPort.Id);
                WinMidi.Check(WinMidi.midiOutOpen(out output, to.Id, IntPtr.Zero, UIntPtr.Zero, 0), "Open output '" + to.Name + "'", false);
                WinMidi.Check(WinMidi.midiInOpen(out input, from.Id, callback, UIntPtr.Zero, 0x30000), "Open input '" + from.Name + "'", true);
                for (int i = 0; i < 8; i++)
                {
                    MidiBuffer buffer = new MidiBuffer(65536); inputBuffers.Add(buffer);
                    WinMidi.Check(WinMidi.midiInPrepareHeader(input, buffer.Pointer, WinMidi.HeaderSize), "Prepare MIDI input", true);
                    buffer.Prepared = true;
                    WinMidi.Check(WinMidi.midiInAddBuffer(input, buffer.Pointer, WinMidi.HeaderSize), "Queue MIDI input", true);
                }
                WinMidi.Check(WinMidi.midiInStart(input), "Start MIDI input", true);
                State = "Running";
                DateTime checkDevices = DateTime.UtcNow.AddSeconds(2);
                while (!stop)
                {
                    if (callbackError != null) throw new InvalidOperationException(callbackError);
                    Packet packet;
                    while (!stop && queue.TryDequeue(out packet))
                    {
                        Interlocked.Decrement(ref queued);
                        if (packet.Kind == 0x3C5 || packet.Kind == 0x3C6)
                            throw new InvalidOperationException("The device sent malformed MIDI. Routing stopped; reconnect the BeatStep and try again.");
                        if (packet.Kind == 0x3C4) ProcessLong(new IntPtr(unchecked((long)packet.Data.ToUInt64())));
                        else ProcessShort(unchecked((uint)packet.Data.ToUInt64()));
                    }
                    ReleaseCompletedOutput();
                    if (DateTime.UtcNow >= checkDevices)
                    {
                        Find(WinMidi.Inputs(), from.Name, from.Id);
                        Find(WinMidi.Outputs(), to.Name, to.Id);
                        checkDevices = DateTime.UtcNow.AddSeconds(2);
                    }
                    signal.WaitOne(20);
                }
            }
            catch (Exception exception) { Error = exception.Message; Log.Write(exception.ToString()); }
            finally
            {
                stop = true;
                Cleanup();
                State = Error == null ? "Stopped" : "Error";
                GC.KeepAlive(callback);
            }
        }

        internal static MidiPort Find(List<MidiPort> ports, string name, uint id)
        {
            // Do not silently route into a different port if an ID was reassigned.
            foreach (MidiPort p in ports) if (p.Id == id && p.Name == name) return p;
            throw new InvalidOperationException("MIDI port '" + name + "' changed or disconnected. Reconnect it, refresh the ports, and start again.");
        }

        private void ProcessShort(uint raw)
        {
            Interlocked.Increment(ref Received);
            uint cleaned;
            bool send = filter.Process(raw, out cleaned);
            if (send)
            {
                WinMidi.Check(WinMidi.midiOutShortMsg(output, cleaned), "Send MIDI", false);
                Interlocked.Increment(ref Sent);
            }
            else Interlocked.Increment(ref Filtered);
            if ((raw & 0xF0) == 0xB0)
                Latest = "CH " + ((raw & 15) + 1) + "   CC " + ((raw >> 8) & 127) + "   " + ((raw >> 16) & 127) +
                    "  ->  " + (send ? ((cleaned >> 16) & 127).ToString() : "filtered");
            else if ((raw & 0xF0) == 0x80 || (raw & 0xF0) == 0x90)
                Latest = "CH " + ((raw & 15) + 1) + "   Note " + ((raw >> 8) & 127) + "   passed through";
        }

        private void ProcessLong(IntPtr headerPointer)
        {
            MidiBuffer buffer = inputBuffers.Find(delegate(MidiBuffer b) { return b.Pointer == headerPointer; });
            if (buffer == null) throw new InvalidOperationException("The MIDI driver returned an unknown buffer.");
            WinMidi.Header header = buffer.Read();
            if (header.Recorded > header.Length) throw new InvalidOperationException("The MIDI driver returned an invalid buffer length.");
            byte[] bytes = new byte[(int)header.Recorded];
            Marshal.Copy(header.Data, bytes, 0, bytes.Length);
            // WinMM may split a large SysEx message across multiple input buffers.
            foreach (byte value in bytes)
            {
                sysex.WriteByte(value);
                if (sysex.Length > 1048576) throw new InvalidOperationException("SysEx exceeded 1 MB. Routing stopped to prevent excessive memory use.");
                if (value == 0xF7)
                {
                    SendLong(sysex.ToArray()); sysex.SetLength(0);
                    Interlocked.Increment(ref Received); Interlocked.Increment(ref Sent);
                    Latest = "SysEx   passed through unchanged";
                }
            }
            Marshal.WriteInt32(buffer.Pointer, IntPtr.Size + 4, 0); // dwBytesRecorded
            WinMidi.Check(WinMidi.midiInAddBuffer(input, buffer.Pointer, WinMidi.HeaderSize), "Requeue MIDI input", true);
        }

        private void SendLong(byte[] bytes)
        {
            ReleaseCompletedOutput();
            if (outputBuffers.Count >= 64) throw new InvalidOperationException("The output cannot keep up with SysEx. Routing stopped; check for MIDI feedback.");
            MidiBuffer buffer = new MidiBuffer(bytes.Length); outputBuffers.Add(buffer);
            Marshal.Copy(bytes, 0, buffer.Data, bytes.Length);
            WinMidi.Check(WinMidi.midiOutPrepareHeader(output, buffer.Pointer, WinMidi.HeaderSize), "Prepare SysEx output", false);
            buffer.Prepared = true;
            WinMidi.Check(WinMidi.midiOutLongMsg(output, buffer.Pointer, WinMidi.HeaderSize), "Send SysEx", false);
        }

        private void ReleaseCompletedOutput()
        {
            for (int i = outputBuffers.Count - 1; i >= 0; i--)
            {
                MidiBuffer b = outputBuffers[i];
                if ((b.Read().Flags & 1) == 0) continue;
                WinMidi.Check(WinMidi.midiOutUnprepareHeader(output, b.Pointer, WinMidi.HeaderSize), "Release SysEx output", false);
                b.Prepared = false; b.Free(); outputBuffers.RemoveAt(i);
            }
        }

        private void Cleanup()
        {
            // Reset returns native buffers before they can be unprepared/freed.
            // Never free a buffer when the driver still owns it, even on failure.
            if (input != IntPtr.Zero)
            {
                WinMidi.midiInStop(input);
                uint reset = WinMidi.midiInReset(input);
                foreach (MidiBuffer b in inputBuffers)
                {
                    uint result = b.Prepared ? WinMidi.midiInUnprepareHeader(input, b.Pointer, WinMidi.HeaderSize) : 0;
                    if (result == 0) b.Free(); else RecordCleanupError("Release input buffer", result, true);
                }
                if (reset != 0) RecordCleanupError("Reset input", reset, true);
                uint close = WinMidi.midiInClose(input);
                if (close != 0) RecordCleanupError("Close input", close, true);
                // Keep this callback rooted if a broken driver refuses to close.
                if (close != 0) GCHandle.Alloc(callback);
                input = IntPtr.Zero;
            }
            if (output != IntPtr.Zero)
            {
                // Reset also releases held notes when the cleaner stops.
                uint reset = WinMidi.midiOutReset(output);
                foreach (MidiBuffer b in outputBuffers)
                {
                    uint result = b.Prepared ? WinMidi.midiOutUnprepareHeader(output, b.Pointer, WinMidi.HeaderSize) : 0;
                    if (result == 0) b.Free(); else RecordCleanupError("Release output buffer", result, false);
                }
                if (reset != 0) RecordCleanupError("Reset output", reset, false);
                uint close = WinMidi.midiOutClose(output);
                if (close != 0) RecordCleanupError("Close output", close, false);
                output = IntPtr.Zero;
            }
            sysex.Dispose();
            // The UI disposes the signal after Join, preventing a final-stop race.
        }
        private void RecordCleanupError(string action, uint code, bool isInput)
        {
            try { WinMidi.Check(code, action, isInput); }
            catch (Exception ex) { if (Error == null) Error = ex.Message; Log.Write(ex.ToString()); }
        }
    }
}
