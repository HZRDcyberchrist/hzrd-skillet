using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Hzrd.BeatStepCleaner
{
    internal static class Theme
    {
        // The Altar page's --bg / --g values, with readable secondary UI text.
        internal static readonly Color Background = Color.FromArgb(1, 4, 3);
        internal static readonly Color Card = Color.FromArgb(3, 11, 7);
        internal static readonly Color Input = Color.FromArgb(2, 8, 5);
        internal static readonly Color Green = Color.FromArgb(61, 255, 154);
        internal static readonly Color Text = Green;
        internal static readonly Color Muted = Color.FromArgb(130, 190, 157);
        internal static readonly Color Border = Color.FromArgb(23, 91, 53);
        internal static readonly Color Dim = Color.FromArgb(10, 34, 21);
        internal static readonly Color Warning = Color.FromArgb(242, 187, 104);
        private static readonly PrivateFontCollection fonts = new PrivateFontCollection();
        private static readonly List<IntPtr> memory = new List<IntPtr>(), registrations = new List<IntPtr>();
        internal static readonly FontFamily Family;

        [DllImport("gdi32.dll")] private static extern IntPtr AddFontMemResourceEx(IntPtr bytes, uint size, IntPtr reserved, ref uint count);
        [DllImport("gdi32.dll")] private static extern bool RemoveFontMemResourceEx(IntPtr handle);

        static Theme()
        {
            try
            {
                AddFont("HZRD.Font.Regular"); AddFont("HZRD.Font.Bold");
                Family = fonts.Families[0];
                AppDomain.CurrentDomain.ProcessExit += delegate
                {
                    foreach (IntPtr registration in registrations) RemoveFontMemResourceEx(registration);
                    fonts.Dispose(); foreach (IntPtr block in memory) Marshal.FreeHGlobal(block);
                };
            }
            catch { Family = new FontFamily("Consolas"); }
        }
        private static void AddFont(string name)
        {
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
            {
                if (stream == null) throw new InvalidDataException("Embedded typeface missing.");
                byte[] bytes = new byte[stream.Length];
                int offset = 0;
                while (offset < bytes.Length) { int read = stream.Read(bytes, offset, bytes.Length - offset); if (read == 0) throw new EndOfStreamException(); offset += read; }
                IntPtr block = Marshal.AllocHGlobal(bytes.Length); memory.Add(block);
                Marshal.Copy(bytes, 0, block, bytes.Length);
                fonts.AddMemoryFont(block, bytes.Length);
                uint count = 0; IntPtr registration = AddFontMemResourceEx(block, (uint)bytes.Length, IntPtr.Zero, ref count);
                if (registration != IntPtr.Zero) registrations.Add(registration);
            }
        }
    }

    internal sealed class CardPanel : Panel
    {
        internal CardPanel() { DoubleBuffered = true; BackColor = Theme.Card; Padding = new Padding(18, 12, 18, 12); }
        protected override void OnPaint(PaintEventArgs e)
        {
            using (Pen border = new Pen(Theme.Border)) e.Graphics.DrawRectangle(border, 0, 0, Width - 1, Height - 1);
            using (Pen accent = new Pen(Theme.Green))
            {
                e.Graphics.DrawLine(accent, 0, 0, 14, 0); e.Graphics.DrawLine(accent, 0, 0, 0, 14);
                e.Graphics.DrawLine(accent, Width - 15, Height - 1, Width - 1, Height - 1);
                e.Graphics.DrawLine(accent, Width - 1, Height - 15, Width - 1, Height - 1);
            }
            base.OnPaint(e);
        }
    }

    internal sealed class SoftButton : Button
    {
        internal Color Fill = Theme.Input;
        private bool hover;
        internal SoftButton() { FlatStyle = FlatStyle.Flat; FlatAppearance.BorderSize = 0; Cursor = Cursors.Hand; DoubleBuffered = true; TabStop = true; }
        protected override void OnMouseEnter(EventArgs e) { hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { hover = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnPaint(PaintEventArgs e)
        {
            bool primary = Fill == Theme.Green;
            Color background = Enabled && hover ? Theme.Green : (primary ? Color.FromArgb(5, 25, 14) : Theme.Input);
            e.Graphics.Clear(background);
            using (Pen glow = new Pen(Color.FromArgb(Enabled ? 38 : 12, Theme.Green)))
                e.Graphics.DrawRectangle(glow, 0, 0, Width - 1, Height - 1);
            using (Pen border = new Pen(Enabled ? (primary || hover ? Theme.Green : Theme.Border) : Theme.Border))
                e.Graphics.DrawRectangle(border, 1, 1, Width - 3, Height - 3);
            string text = "[ " + Text.ToLowerInvariant() + " ]";
            TextRenderer.DrawText(e.Graphics, text, Font, ClientRectangle, Enabled && hover ? Theme.Background : (Enabled ? Theme.Green : Theme.Muted),
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
            if (Focused) ControlPaint.DrawFocusRectangle(e.Graphics, new Rectangle(6, 6, Width - 12, Height - 12), Theme.Green, background);
        }
    }

    internal sealed class KnobBuddy : Control
    {
        internal bool Active;
        internal KnobBuddy() { DoubleBuffered = true; Size = new Size(80, 80); BackColor = Theme.Background; }
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.ScaleTransform(Width / 80f, Height / 80f);
            Color ink = Active ? Theme.Green : Color.FromArgb(34, 181, 106);
            // A cathedral window enclosing a rotary encoder, rendered as code.
            using (Pen ghost = new Pen(Color.FromArgb(35, ink), 5))
            using (Pen line = new Pen(ink, 1))
            {
                PointF[] arch = new PointF[] { new PointF(13, 73), new PointF(13, 33), new PointF(23, 18), new PointF(40, 7), new PointF(57, 18), new PointF(67, 33), new PointF(67, 73) };
                e.Graphics.DrawLines(ghost, arch); e.Graphics.DrawLines(line, arch);
                e.Graphics.DrawLine(line, 13, 73, 67, 73);
                e.Graphics.DrawLine(line, 40, 12, 40, 28); e.Graphics.DrawLine(line, 34, 19, 46, 19);
                e.Graphics.DrawEllipse(line, 24, 33, 32, 32);
                e.Graphics.DrawLine(line, 40, 36, 40, 42);
                e.Graphics.DrawLine(line, 7, 58, 7, 74); e.Graphics.DrawLine(line, 73, 58, 73, 74);
            }
            using (Font font = new Font(Theme.Family, 7, FontStyle.Regular, GraphicsUnit.Pixel))
            using (Brush brush = new SolidBrush(ink))
            {
                e.Graphics.DrawString("::", font, brush, 35, 47);
                e.Graphics.DrawString("+", font, brush, 4, 48); e.Graphics.DrawString("+", font, brush, 69, 48);
            }
            using (Pen scan = new Pen(Color.FromArgb(55, Theme.Background)))
                for (int y = 1; y < 80; y += 3) e.Graphics.DrawLine(scan, 0, y, 80, y);
        }
    }

    internal sealed class DarkCombo : ComboBox
    {
        internal DarkCombo()
        {
            DrawMode = DrawMode.OwnerDrawFixed;
            DrawItem += delegate(object sender, DrawItemEventArgs e)
            {
                using (Brush background = new SolidBrush(Theme.Input)) e.Graphics.FillRectangle(background, e.Bounds);
                string text = e.Index >= 0 && e.Index < Items.Count ? Items[e.Index].ToString() : Text;
                Rectangle bounds = e.Bounds; bounds.X += 6; bounds.Width -= 6;
                TextRenderer.DrawText(e.Graphics, text, Font, bounds, Enabled ? Theme.Text : Theme.Muted,
                    TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
                if (Enabled && (e.State & DrawItemState.Focus) != 0) e.DrawFocusRectangle();
            };
        }
        private void PaintChrome(Graphics graphics)
        {
            int arrowWidth = Math.Max(20, Height - 6);
            Rectangle arrow = new Rectangle(Width - arrowWidth - 1, 1, arrowWidth, Height - 2);
            using (Brush fill = new SolidBrush(Theme.Input)) graphics.FillRectangle(fill, arrow);
            using (Pen border = new Pen(Enabled ? Theme.Green : Theme.Border)) graphics.DrawRectangle(border, 0, 0, Width - 1, Height - 1);
            int cx = arrow.Left + arrow.Width / 2, cy = Height / 2;
            using (Pen pen = new Pen(Enabled ? Theme.Green : Theme.Muted))
                graphics.DrawLines(pen, new Point[] { new Point(cx - 4, cy - 2), new Point(cx, cy + 2), new Point(cx + 4, cy - 2) });
        }
        protected override void WndProc(ref Message message)
        {
            base.WndProc(ref message);
            if (message.Msg == 0xF) { using (Graphics graphics = CreateGraphics()) PaintChrome(graphics); }
            else if ((message.Msg == 0x317 || message.Msg == 0x318) && message.WParam != IntPtr.Zero)
            { using (Graphics graphics = Graphics.FromHdc(message.WParam)) PaintChrome(graphics); }
        }
    }

    internal sealed class DarkCheckBox : CheckBox
    {
        internal DarkCheckBox() { SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true); }
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor);
            int size = Math.Max(14, (int)(Height * .58f)); int y = (Height - size) / 2;
            Rectangle box = new Rectangle(1, y, size, size);
            using (Brush brush = new SolidBrush(Theme.Input)) e.Graphics.FillRectangle(brush, box);
            using (Pen border = new Pen(Enabled ? Theme.Green : Theme.Muted)) e.Graphics.DrawRectangle(border, box);
            if (Checked)
            {
                using (Pen pen = new Pen(Enabled ? Theme.Green : Theme.Muted, 2))
                    e.Graphics.DrawLines(pen, new Point[] { new Point(4, y + size / 2), new Point(7, y + size - 4), new Point(size - 2, y + 4) });
            }
            Rectangle text = new Rectangle(size + 10, 0, Width - size - 10, Height);
            TextRenderer.DrawText(e.Graphics, Text, Font, text, Enabled ? Theme.Text : Theme.Muted,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
            if (Focused) ControlPaint.DrawFocusRectangle(e.Graphics, text, Theme.Text, BackColor);
        }
    }
}
