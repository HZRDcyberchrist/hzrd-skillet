using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using System.Xml;

[assembly: AssemblyTitle("HZRD BeatStep Cleaner")]
[assembly: AssemblyDescription("Portable BeatStep relative encoder cleaner for Windows")]
[assembly: AssemblyCompany("HZRD")]
[assembly: AssemblyProduct("HZRD BeatStep Cleaner")]
[assembly: AssemblyVersion("2.1.0.0")]
[assembly: AssemblyFileVersion("2.1.0.0")]
[assembly: AssemblyCopyright("Copyright (c) 2026 HZRD")]

namespace Hzrd.BeatStepCleaner
{
    internal static class Log
    {
        internal static string DirectoryPath;
        private static readonly object gate = new object();
        internal static void Configure(string path)
        {
            DirectoryPath = path ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HZRD", "BeatStepCleaner");
        }
        internal static void Write(string text)
        {
            try
            {
                lock (gate)
                {
                    Directory.CreateDirectory(DirectoryPath);
                    string path = Path.Combine(DirectoryPath, "cleaner.log");
                    if (File.Exists(path) && new FileInfo(path).Length > 524288) File.Move(path, path + "." + DateTime.UtcNow.Ticks + ".old");
                    File.AppendAllText(path, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + text + Environment.NewLine);
                    string[] old = Directory.GetFiles(DirectoryPath, "cleaner.log.*.old");
                    Array.Sort(old, StringComparer.Ordinal);
                    for (int i = 0; i < old.Length - 1; i++) File.Delete(old[i]);
                }
            }
            catch { /* Logging must never interrupt a live MIDI session. */ }
        }
    }

    internal sealed class Settings
    {
        internal string Input = "Arturia BeatStep", Output = "HZRD BeatStep";
        internal int Confirm = 2;
        internal bool AllControllers = true;
        internal string Controllers = "7";
        internal string Warning;
        internal static Settings Load()
        {
            Settings settings = new Settings();
            string path = Path.Combine(Log.DirectoryPath, "settings.xml");
            if (!File.Exists(path)) return settings;
            try
            {
                XmlDocument document = new XmlDocument();
                document.XmlResolver = null;
                using (XmlReader reader = XmlReader.Create(path, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null })) document.Load(reader);
                XmlElement root = document.DocumentElement;
                if (root == null || root.Name != "BeatStepCleaner") throw new InvalidDataException("Unknown settings format.");
                settings.Input = root.GetAttribute("input"); settings.Output = root.GetAttribute("output");
                int value;
                if (int.TryParse(root.GetAttribute("confirm"), out value) && value >= 1 && value <= 4) settings.Confirm = value;
                bool all;
                if (bool.TryParse(root.GetAttribute("allControllers"), out all)) settings.AllControllers = all;
                if (root.HasAttribute("controllers")) settings.Controllers = root.GetAttribute("controllers");
            }
            catch (Exception ex)
            {
                Log.Write("Settings could not be read: " + ex.Message);
                settings = new Settings(); settings.Warning = "Saved settings could not be read. Defaults restored; check your ports before starting.";
            }
            return settings;
        }
        internal void Save()
        {
            Directory.CreateDirectory(Log.DirectoryPath);
            string path = Path.Combine(Log.DirectoryPath, "settings.xml");
            string temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                XmlDocument document = new XmlDocument();
                XmlElement root = document.CreateElement("BeatStepCleaner"); document.AppendChild(root);
                root.SetAttribute("version", "2"); root.SetAttribute("input", Input); root.SetAttribute("output", Output);
                root.SetAttribute("confirm", Confirm.ToString()); root.SetAttribute("allControllers", AllControllers.ToString());
                root.SetAttribute("controllers", Controllers);
                document.Save(temporary);
                if (File.Exists(path)) File.Replace(temporary, path, null); else File.Move(temporary, path);
            }
            finally { if (File.Exists(temporary)) File.Delete(temporary); }
        }
    }

    internal static class Program
    {
        [DllImport("user32.dll")] private static extern bool SetProcessDPIAware();
        [DllImport("user32.dll")] private static extern bool SetProcessDpiAwarenessContext(IntPtr context);
        [STAThread]
        private static int Main(string[] args)
        {
            string dataPath = null;
            for (int i = 0; i < args.Length - 1; i++) if (args[i] == "--data-dir") dataPath = Path.GetFullPath(args[i + 1]);
            Log.Configure(dataPath);
            try
            {
                // The manifest enables per-monitor DPI on modern Windows.
                try { if (!SetProcessDpiAwarenessContext(new IntPtr(-4))) SetProcessDPIAware(); }
                catch (EntryPointNotFoundException) { SetProcessDPIAware(); }
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                if (args.Length >= 2 && args[0] == "--self-test") return SelfTests.Run(Path.GetFullPath(args[1]));
                if (args.Length >= 2 && args[0] == "--diagnostics") return SelfTests.Diagnostics(Path.GetFullPath(args[1]));
                if (args.Length >= 2 && args[0] == "--ui-test") return SelfTests.UiTest(Path.GetFullPath(args[1]));
                bool created;
                using (Mutex mutex = new Mutex(true, "Local\\HZRD_BeatStep_Cleaner_v2", out created))
                {
                    if (!created) { MessageBox.Show("BeatStep Cleaner is already open. Find its window on the taskbar.", "HZRD BeatStep Cleaner", MessageBoxButtons.OK, MessageBoxIcon.Information); return 0; }
                    Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                    Application.ThreadException += delegate(object sender, ThreadExceptionEventArgs e) { Fatal(e.Exception); Application.Exit(); };
                    Application.Run(new CleanerForm());
                    mutex.ReleaseMutex();
                }
                return 0;
            }
            catch (Exception ex) { Fatal(ex); return 1; }
        }
        private static void Fatal(Exception exception)
        {
            Log.Write(exception.ToString());
            MessageBox.Show("BeatStep Cleaner could not continue.\n\n" + exception.Message + "\n\nDetails are saved in:\n" + Log.DirectoryPath +
                "\n\nReconnect your MIDI devices and try again.", "HZRD BeatStep Cleaner", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
