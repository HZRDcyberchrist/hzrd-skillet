# HZRD BeatStep Cleaner 2.1 - Altar edition

A portable Windows replacement for the Python package. Run **HZRD BeatStep Cleaner.exe** after extracting the ZIP. Read **START HERE.txt** for setup.

```
Arturia BeatStep -> HZRD BeatStep Cleaner -> HZRD BeatStep (loopMIDI) -> Resolume
```

## What changed

The old installer could ask pip to compile python-rtmidi when a compatible wheel was unavailable. The failed installation then left mido missing. This edition replaces that dependency chain with C# / Windows Forms and the Windows WinMM MIDI API. The packaged EXE has no third-party library dependencies, uses no Python, performs no downloads, and runs without administrator access. It does use the Windows .NET Framework 4 runtime. [Microsoft documents the runtime included in Windows](https://learn.microsoft.com/en-us/dotnet/framework/install/on-windows-and-server).

The original Python ZIP was not available in the referenced conversation's attachments. The MIDI core was rebuilt from the documented features and exact Bome rules. Version 2.1 themes that utility after the [HZRD Altar page](https://hzrdarchive.com/pages/altar): near-black (#010403), phosphor green (#3dff9a), square outlined controls, monospace typography, subtle ASCII drift and a cathedral-window encoder emblem. The small decorative header updates at 1 Hz and pauses when minimized. The MIDI worker remains independent of visual updates.

IBM Plex Mono Regular and Bold are embedded in the EXE and registered only within its process; no font installation or startup download is needed. The unmodified fonts are from [Google Fonts](https://github.com/google/fonts/tree/main/ofl/ibmplexmono) and are licensed under SIL OFL 1.1. See source/fonts/OFL.txt. Source font files are included for optional rebuilds.

## Behavior

- Automatically selects the Arturia BeatStep and HZRD BeatStep ports when present. Previously selected names take priority. Unrelated MIDI devices are never selected automatically.
- Direction Confirm defaults to 2 and can be set to 1-4.
- Selected CC values 1-63 normalize to 1; 65-127 normalize to 127; 0 and 64 are ignored as neutral.
- Correct-direction messages pass immediately. Consecutive opposing messages must reach the confirmation threshold before the reversal is accepted. A correct-direction pulse clears a pending reversal. Ignored pulses are never replayed.
- Direction state is separate for every MIDI channel/controller pair, covering all 16 BeatStep encoders without shared state. It persists until Stop/Start, with no time-based reset.
- All CCs are cleaned by default. A comma/range list allows cleaning only encoder CCs so absolute CC buttons pass through unchanged.
- Notes, program changes, pressure, pitch bend, transport/clock and other short MIDI pass unchanged. Valid complete SysEx is reconstructed across input chunks and sent unchanged. SysEx is bounded at 1 MB, with at most 64 pending output buffers; exceeding those limits stops routing with an error. This is a controller utility, not a firmware-update transport.
- Missing ports, busy devices, changed port IDs, malformed MIDI and queue overflow produce clear errors. Identical input/output names are blocked to prevent the simplest feedback route. A loop created by other applications can still cause feedback.
- Settings save on Start and Close. Corrupt settings fall back to defaults with an explanation. Error logs rotate and do not interrupt MIDI processing.

## Performance and lifecycle

The driver callback only queues events. A single background worker owns device opening, MIDI output and buffer recycling. It performs no MIDI API calls inside the callback, following [Microsoft's callback guidance](https://learn.microsoft.com/en-us/previous-versions/dd798460(v=vs.85)). UI counters refresh at 10 Hz and never schedule one UI update per incoming pulse. Event signaling wakes the worker as messages arrive; its 20 ms maintenance wait is not a deliberate delay applied to each message.

Stopping resets and closes the MIDI devices, unprepares native buffers, and releases them only after the driver returns ownership. Output reset can also issue note-off messages to release held notes. The app periodically checks that selected port IDs still name the selected devices. It stops on a disconnection rather than reconnecting to an unintended port.

## Troubleshooting

1. Extract the whole ZIP before starting. Run the EXE, or run.bat for a basic runtime/extraction check. install.bat only launches this portable build.
2. If the BeatStep input is busy, close Bome, the old cleaner and MIDI Control Center, then refresh ports. Keep the direct Arturia input disabled in Resolume.
3. If the output is missing, open loopMIDI and create HZRD BeatStep, then refresh ports. Keep loopMIDI running throughout the session.
4. If a knob produces IN/OUT activity but the target stays still, check Resolume's selected input, encoder mode and Relative mapping.
5. If a button misbehaves, switch off Clean all CCs and list only the encoder CCs.
6. If ports appear but receive no MIDI, check Windows updates and reconnect/restart the MIDI applications. Microsoft has documented problems with dynamically created virtual MIDI endpoints in some Windows MIDI Services releases; this is a possible cause, not a diagnosis of every no-data case. [Microsoft's issue notes](https://devblogs.microsoft.com/windows-music-dev/windows-midi-services-rollout-known-issues-and-workarounds/) explain their current status. The cleaner does not modify Windows services, registry entries or drivers.
7. Use Setup & help to open the settings/log folder. check.bat saves an offline self-test report and a port inventory in checks/. It does not test hardware routing.

## Optional source build

`build_exe.bat` uses the C# compiler already supplied with the Windows .NET Framework where it is available. It compiles the included source into an AnyCPU Windows Forms EXE, with optimization and warnings treated as errors. It downloads and installs nothing. A build failure does not prevent using the included prebuilt EXE.

The runtime is .NET Framework 4, not the separate modern .NET SDK. Normal Windows 10 and Windows 11 installations include a compatible 4.x runtime. The EXE runs as a 64-bit process on the tested x64 Windows installation. 32-bit Windows and Windows on ARM were not tested.

This edition is unsigned. No Microsoft, Arturia, Resolume or loopMIDI affiliation is implied. loopMIDI and its driver are separate third-party software and are not redistributed in this package. See LICENSE.txt for this edition's source.

See TESTED.txt for actual validation and remaining limits. interface-preview.png shows a simulated running state; it is not evidence of hardware MIDI reception.
