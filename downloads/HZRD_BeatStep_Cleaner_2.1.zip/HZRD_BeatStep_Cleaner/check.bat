@echo off
setlocal
cd /d "%~dp0"
title HZRD BeatStep Cleaner - Check
if not exist "HZRD BeatStep Cleaner.exe" goto missing
if not exist "checks" mkdir "checks"
if not exist "checks" goto unwritable
start "" /wait "HZRD BeatStep Cleaner.exe" --self-test "checks\self-test.txt" --data-dir "checks\app-data"
if errorlevel 1 goto failed
start "" /wait "HZRD BeatStep Cleaner.exe" --diagnostics "checks\midi-ports.txt" --data-dir "checks\app-data"
if errorlevel 1 goto failed
echo All checks passed. No MIDI ports were opened and no messages were sent.
echo Reports are in the checks folder.
pause
exit /b 0
:missing
echo Extract the full ZIP first. HZRD BeatStep Cleaner.exe is missing.
pause
exit /b 1
:unwritable
echo This folder cannot be written to. Extract the ZIP into a folder you own.
pause
exit /b 1
:failed
echo A check failed. See the reports in the checks folder.
pause
exit /b 1
