@echo off
setlocal
cd /d "%~dp0"
title HZRD BeatStep Cleaner
if not exist "%~dp0HZRD BeatStep Cleaner.exe" goto missing
if not exist "%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\mscorlib.dll" goto runtime
start "" "%~dp0HZRD BeatStep Cleaner.exe"
if errorlevel 1 goto launchfailed
exit /b 0
:missing
echo The Cleaner EXE is missing from this folder.
echo Right-click the downloaded ZIP and choose Extract All, then try again.
echo If Windows Security quarantined it, review the recorded detection first.
echo Download a fresh copy if extraction was incomplete.
pause
exit /b 1
:runtime
echo Windows .NET Framework is unavailable on this computer.
echo Install the free Microsoft .NET Framework 4.8 runtime, then try again:
echo https://dotnet.microsoft.com/download/dotnet-framework/net48
echo No Python, pip, Visual Studio, or C/C++ tools are needed.
pause
exit /b 1
:launchfailed
echo Windows could not start the cleaner.
echo Extract the ZIP completely and try opening the EXE directly.
echo Review Windows Security if it reports a specific block.
pause
exit /b 1
