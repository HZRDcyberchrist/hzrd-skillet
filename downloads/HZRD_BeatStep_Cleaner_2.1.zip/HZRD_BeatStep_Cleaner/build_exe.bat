@echo off
setlocal
cd /d "%~dp0"
set "HZRD_CSC=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%HZRD_CSC%" set "HZRD_CSC=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%HZRD_CSC%" goto missing
echo Building HZRD BeatStep Cleaner from the included source...
"%HZRD_CSC%" /nologo /target:winexe /platform:anycpu /optimize+ /warn:4 /warnaserror+ /out:"HZRD BeatStep Cleaner.exe" /win32manifest:"source\app.manifest" /win32icon:"source\cleaner.ico" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Xml.dll /reference:System.Core.dll /resource:"source\fonts\IBMPlexMono-Regular.ttf",HZRD.Font.Regular /resource:"source\fonts\IBMPlexMono-Bold.ttf",HZRD.Font.Bold "source\AltarTheme.cs" "source\MidiCore.cs" "source\NativeMidi.cs" "source\Program.cs" "source\CleanerForm.cs" "source\SelfTests.cs"
if errorlevel 1 goto failed
copy /y "source\app.config" "HZRD BeatStep Cleaner.exe.config" >nul
if errorlevel 1 goto failed
echo Build complete. Run "HZRD BeatStep Cleaner.exe".
exit /b 0
:missing
echo The optional source build needs the Windows .NET Framework C# compiler.
echo You do not need to build anything to use the included EXE.
exit /b 1
:failed
echo Build failed. Review the error above. The included EXE is ready to use.
exit /b 1
